const teethTone = 'BL3'

const darkTransparency = 0.2
const nonLinear = 0.7

bnb.scene.enableRecognizerFeature(bnb.FeatureID.TEETH_TONE)

const vitaLab = {
  "BL1": [215.0, 130.0, 123.0], 
  "BL2": [209.0, 130.0, 125.0], 
  "BL3": [209.0, 129.0, 128.0], 
  "BL4": [203.0, 129.0, 131.0], 
  "A1":  [203.0, 127.0, 135.0], 
  "A2":  [192.0, 128.0, 140.0], 
  "A3":  [194.0, 128.0, 141.0], 
  "A35": [186.0, 128.0, 148.0], 
  "A4":  [177.0, 130.0, 146.0], 
  "B1":  [197.0, 128.0, 132.0], 
  "B2":  [199.0, 127.0, 139.0], 
  "B3":  [187.0, 127.0, 148.0], 
  "B4":  [187.0, 128.0, 149.0], 
  "C1":  [189.0, 128.0, 136.0], 
  "C2":  [184.0, 127.0, 142.0], 
  "C3":  [176.0, 128.0, 144.0], 
  "C4":  [167.0, 129.0, 147.0], 
  "D2":  [187.0, 128.0, 136.0], 
  "D3":  [188.0, 127.0, 143.0], 
  "D4":  [182.0, 127.0, 144.0]

}

const applyTeethTone = (teethTone, darkTransparency, nonLinear) => {
  const sellectedTone = vitaLab[teethTone]
  const color = new bnb.FeatureParameter(sellectedTone[0], sellectedTone[1], sellectedTone[2], 0)
  const maskSetup =  new bnb.FeatureParameter(darkTransparency, nonLinear, 0, 0)
  bnb.scene.addFeatureParam(bnb.FeatureID.TEETH_TONE, [color, maskSetup])
}

applyTeethTone(teethTone, darkTransparency, nonLinear)